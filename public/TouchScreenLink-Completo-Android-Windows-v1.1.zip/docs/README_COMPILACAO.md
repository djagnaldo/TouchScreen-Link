# TouchScreen Link - Instruções Oficiais de Compilação

## 1. Aplicativo Android Nativo
- Pré-requisitos: JDK 17 e Android SDK 34
- Comando:
  cd android
  ./gradlew assembleRelease
  (ou gradlew.bat assembleRelease no Windows)
- Saída: android/app/build/outputs/apk/release/app-release-unsigned.apk

## 2. Servidor Windows Nativo
- Pré-requisitos: .NET 8 SDK
- Comando:
  cd windows
  dotnet publish TouchScreenLink.Server/TouchScreenLink.Server.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
- Saída: windows/TouchScreenLink.Server/bin/Release/net8.0-windows10.0.19041.0/win-x64/publish/TouchScreenLinkServer.exe
